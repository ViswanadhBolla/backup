﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLibrary
{
    public class SBAccount
    {
        public long accountNumber { get; }
        string customerName, customerAdress;
        public float currentBalance { get;  set; }
        static long accno = 100000000001;

        public SBAccount()
        {
            accountNumber = accno;
            accno = accno + 1;
            customerName = "John Doe";
            customerAdress = "adress not found";
            currentBalance = 3000.00f;
        }
        public SBAccount(string customerName,string customerAdress)
        {
            accountNumber = accno;
            accno = accno + 1;
            CustomerName = customerName;
            CustomerAdress = customerAdress;
            currentBalance = 3000.00f;

        }

        public string CustomerName
        {
            get { return customerName; }
            set
            {
                if(value != "")
                {
                    customerName = value;
                }
                else
                {
                    customerName = "John Doe";
                }
            }
        }
        public string CustomerAdress
        {
            get { return customerAdress; }
            set
            {
                if(value != "")
                {
                    customerAdress = value;
                }
                else
                {
                    customerAdress = "Adress not Found";
                }
            }
        }

        public string printDetails()
        {
            return String.Format("Account Number: "+accountNumber
                +"\nCustomer name: "+CustomerName
                +"\nAddress : "+customerAdress
                +"\nBalance: "+currentBalance);
            
        }





    }
}
